# Prijsraming G28 - Offerte 1

-   Groep: ops2-g03
-   Datum: 17-04-2018

| Product                                           | Opmerkingen                | Aantal | Subtotaal | Totaal    | Link                  |
| ------------------------------------------------- | -------------------------- | ------ | --------- | --------- | --------------------- |
| Intel NUC6i7KYK                                   | NUC Barebone               | 3      | € 439,97  | € 1319,91 | https://goo.gl/HeEgp8 |
| WD Blue SSD 250GB M.2                             | SSD NUC                    | 3      | € 67      | € 201     | https://goo.gl/T8eULv |
| Kingston ValueRAM 8GB DDR4                        | RAM NUC                    | 6      | € 95,96   | € 575,76  | https://goo.gl/2H4ywC |
| Acer Aspire C22-860                               | All-in-One                 | 3      | € 479     | € 1437     | https://goo.gl/btAhW5 |
| Asus ChromeBox 2                                  | ChromeBox/Mediaspeler      | 1      | € 175     | € 175     | https://goo.gl/QXkZ6M |
| Benq GL2460                                       | Monitor                    | 3      | €  109    | € 327     | https://goo.gl/M3icrT |
| Logitech MK120                                    | Muis + Toetsenbord         | 6      | € 19      | € 114     | https://goo.gl/q217Mw |
| Benq TW533                                        | Beamer                     | 1      | € 369     | € 369     | https://goo.gl/8cEBNJ |
| Synology NAS: DS918+                              | NAS                        | 1      |  € 489    | € 489     | https://goo.gl/C9NPsm |
| Seagate 3TB SATAIII, 3.5''                        | HDD                        | 4      | € 85      | € 340     | https://goo.gl/tc2APt |
| Brother J5730DW                                   | Multifunctional Printer A3 | 1      | € 179     | € 179     | https://goo.gl/dFy3yv |
| HP Officejet 6230                                 | Inkjetprinter              | 1      | € 74      | € 74      | https://goo.gl/2MqiGB |
| Apple iPad Wi-Fi 32 GB                            | Tablets                    | 2      | € 275     | € 550     | https://goo.gl/1mXNSQ |
| Samsung UE49M5000                                 | LED TV                     | 1      | € 519     | € 519     | https://goo.gl/DLYBFY |
| TP-LINK TL-SG2216                                 | Switch                     | 1      | € 105     | € 105     | https://goo.gl/qrqfqr |
| Linksys WAP300N                                   | AP                         | 1      | € 32      | € 32      | https://goo.gl/Fx1Apa |
| VivoLink Pro HDMI Cable 10 Meter                  | HDMI-Kabel                 | 1      | € 55      | € 55      | https://goo.gl/obRTUF |
| Newstar HDMI Cable 2 Meter                        | HDMI-Kabel                 | 1      | € 16      | € 16      | https://goo.gl/pdxmu8 |
| Eminent 1.8m DisplayPort/DVI -D                   | DisplayPort/DVI-Kabel      | 3      | € 17      | € 51      | https://goo.gl/AEHJd3 |
| Advanced Cable Technology CAT5E UTP (ES100H) 100m | Ethernetkabel              | 1      | € 49      | € 49      | https://goo.gl/CB6yAA |
| Advanced Cable Technology kabel connector: RJ45   | Connector voor UTP kabel   | 1      | € 14      | € 14      |https://bit.ly/2HGozQj |
| Geschatte uren                                    | Prijs per uur - Bruto      | 10     | € 70      | € 700     |                       |
| Totaal                                            | € 7701,67                  |        |           |           |                       |

\* Alle prijzen exclusief btw
<br/>
\* Alle prijzen afkomstig van centralpoint.be
<br/>
\* Prijs bij leverancier op 20/04/2018
