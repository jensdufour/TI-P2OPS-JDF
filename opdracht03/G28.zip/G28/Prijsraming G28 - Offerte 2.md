# Prijsraming G28 - Offerte 2

-   Groep: ops2-g03
-   Datum: 17-04-2018

| Product                                           | Opmerkingen                | Aantal | Subtotaal | Totaal | Link                  |
| ------------------------------------------------- | -------------------------- | ------ | --------- | ------ | --------------------- |
| Asus VivoBook S15                                 | AutoCAD Laptop             | 3      | € 899     | € 2697 | https://goo.gl/kFN6pP |
| Acer Aspire C22-860                               | All-in-One                 | 2      | € 479     | € 958  | https://goo.gl/btAhW5 |
| Raspberry Pi 3 Model B                            | Microcomputer/Mediaspeler  | 1      | € 92      | € 92   | https://goo.gl/BbZU2e |
| Logitech MK120                                    | Muis + Toetsenbord         | 3      | € 19      | € 57   | https://goo.gl/q217Mw |
| Benq TW533                                        | Beamer                     | 1      | € 369     | € 369  | https://goo.gl/8cEBNJ |
| Synology NAS: DS218+                              | NAS                        | 1      |  € 269    | € 269  | https://goo.gl/1qgQ21 |
| WD 4TB SATAIII, 3.5''                             | HDD                        | 2      | € 109     | € 218  | https://goo.gl/Yyqq3V |
| Kyocera ECOSYS M5521cdw                           | Multifunctional Printer A3 | 1      | € 159     | € 159  | https://goo.gl/Geummd |
| Epson WorkForce WF-2010W                          | Inkjetprinter              | 1      | € 52      | € 52   | https://goo.gl/UHoqvr |
| Salora LED-TV 1600 Series                         | LED TV                     | 1      | € 259     | € 259  | https://goo.gl/BXdPrt |
| TP-LINK TL-SG2216                                 | Switch                     | 1      | € 105     | € 105  | https://goo.gl/qrqfqr |
| Linksys WAP300N                                   | AP                         | 1      | € 32      | € 32   | https://goo.gl/Fx1Apa |
| VivoLink Pro HDMI Cable 10 Meter                  | HDMI-Kabel                 | 1      | € 55      | € 55   | https://goo.gl/JbZ9TJ |
| Advanced Cable Technology kabel connector: RJ45   | Connector voor UTP kabel   | 1      | € 14      | € 14   | https://bit.ly/2HGozQj |
| Advanced Cable Technology CAT5E UTP (ES100H) 100m | Ethernetkabel              | 1      | € 49      | € 49   | https://goo.gl/CB6yAA |
| Geschatte uren                                    | Prijs per uur - Bruto      | 10     | € 35      | € 700  |                       |
| Totaal                                            | € 6085,00                  |        |           |        |                       |

\* Alle prijzen exclusief btw
<br/>
\* Alle prijzen afkomstig van centralpoint.be
<br/>
\* Prijs bij leverancier op 20/04/2018
